Save here the data from the ARI database, http://www.oeaw.ac.at/isf/hrtf
Direct link to ARI database: https://projects.ari.oeaw.ac.at/research/experimental_audiology/hrtf/database/hrtfItEARI.html

The data must be in the format as downloaded from ARI, that is NHX\hrtf_M_dtf 256.mat where NHX is the ARI subject ID. 

SOFA Toolbox for Matlab and Octave
Piotr Majdak, ARI, OeAW
