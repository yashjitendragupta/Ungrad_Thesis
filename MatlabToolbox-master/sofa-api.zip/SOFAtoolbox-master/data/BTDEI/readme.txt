Save here the data from the BT-DEI database, http://padva.dei.unipd.it/?page_id=345
The data must be in the format as downloaded from BT-DEI, that is HXXX\SYYY\... where XXX is the headphone type and YYY the subject ID (three digits each). 

SOFA Toolbox for Matlab and Octave
Piotr Majdak, ARI, OeAW
