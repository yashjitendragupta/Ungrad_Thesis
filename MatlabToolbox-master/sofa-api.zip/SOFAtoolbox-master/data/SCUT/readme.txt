Save here the data from the SCUT database (Bosun Xie, Ghongzhou, China)
The data must be in the format as provided by the SCUT, e.g., the nearfield KEMAR data in the directory "nearfield".

SOFA Toolbox for Matlab and Octave
Piotr Majdak, ARI, OeAW
