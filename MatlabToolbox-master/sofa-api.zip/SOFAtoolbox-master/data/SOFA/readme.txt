SOFA files go here. 

When used with the default settings of SOFAdbURL and SOFAdbPath, this directory reflects http://www.sofacoustics.org/data/


SOFA Toolbox for Matlab and Octave
Piotr Majdak, ARI, OeAW
