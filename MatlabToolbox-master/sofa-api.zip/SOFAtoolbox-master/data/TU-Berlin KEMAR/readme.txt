Save here the data from the TU-Berlin database, https://doi.org/10.5281/zenodo.4459911
The data must be in the format as downloaded from TU Berlin.

SOFA Toolbox for Matlab and Octave
Piotr Majdak, ARI, OeAW
